<template>
  <svg
    class="flex-shrink-0 w-8 h-8 mr-4 fill-current"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 170 170"
  >
    <circle cx="85" cy="85" r="85" />
    <path
      d="M30.08 89.94c8.68 6 13.22 7.1 20.7 19.7s8.79 21.17 10.76 22.75 11.81-.39 16.93-3.15 5.31-4.28 10.09-15.45c6.63-15.5 17.39-34.52 25.66-45.55S139.89 42.72 140.68 40s-7.48-4-15.35-1.67-24.47 20.6-34.48 35c-11.13 16-15.09 29.41-17 29S68 93.85 62.47 87.94s-11.32-9.91-18-8.72-18.39 7.95-14.39 10.72z"
      fill="#fff"
    />
  </svg>
</template>

<script>
export default {
  name: "Bullet",
  data() {
    return {};
  },
};
</script>
