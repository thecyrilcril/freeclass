require('./bootstrap');

require('alpinejs');

import '@fontsource/commissioner/400.css'
import '@fontsource/commissioner/500.css'
import '@fontsource/commissioner/600.css'

import Swal from 'sweetalert2'

window.Swal = Swal
