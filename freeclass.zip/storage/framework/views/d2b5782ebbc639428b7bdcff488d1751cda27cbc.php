<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\freeclass\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>