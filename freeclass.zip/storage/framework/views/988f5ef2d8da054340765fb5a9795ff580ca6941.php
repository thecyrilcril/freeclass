<?php $__env->startComponent('mail::message'); ?>
# Hi <?php echo e($first_name); ?>,

Thank you for registering for My free Pattern drafting class.\
I am so excited😁😁 to introduce you to the\
*Foundations of Modern Fashion design* and also meet you __in real life__.

I have a lot of valuable information and techniques to share with you!!!

<?php $__env->startComponent('mail::subcopy'); ?>
__Important!__\
Because this is an hands-on class, there only a few slots availaible and there is a selection process. You will be contacted once you are selected.

<?php if (isset($__componentOriginalba845ad32dfe5e4470519a452789aeb20250b6fc)): ?>
<?php $component = $__componentOriginalba845ad32dfe5e4470519a452789aeb20250b6fc; ?>
<?php unset($__componentOriginalba845ad32dfe5e4470519a452789aeb20250b6fc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

\
Good luck,<br><br>
<img src="http://freeclass.test/images/Kehinde-oni-avatar.jpg" alt="Kehinde Oni" title="Kehinde Oni, Creative Director, Image Clothia Innovations" width="90"><br>
**Kehinde Oni.**<br>
Creative Director,<br>
<?php echo e(config('app.name')); ?> Innovations.
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\freeclass\resources\views/mail/registration/notification.blade.php ENDPATH**/ ?>