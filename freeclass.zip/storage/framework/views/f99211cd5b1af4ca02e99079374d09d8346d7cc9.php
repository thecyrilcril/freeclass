<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">

<img src="https://freeclass.test/images/logo_mod.png" class="logo" alt="Image Clothia Innovations Logo">


</a>
</td>
</tr>
<?php /**PATH C:\wamp64\www\freeclass\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>