<p align="center"><a href="https://imageclothia.com" target="_blank"><img src="https://imageclothia.com/images/image-clothia-logo.png" width="200"></a></p>

## Image Clothia Free Training

**[Image Clothia](https://imageclothia.com/)**

Built with:

- [Laravel](https://laravel.com/).
- [Tailwindcss](https://tailwindcss.com/).
- [Inertiajs](https://inertiajs.com/).
